mystring= "This is String."
print(mystring)
print(type(mystring))
print(str(mystring)+"is of the data type" + str(type(mystring)))
fristname="water"
secondname="fall"
Thirdname=fristname +secondname
print(Thirdname)
name=input("What is your Name?")
print(name)
